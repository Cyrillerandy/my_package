# my_package
This package was created as an illustration of how to make your own pyhton packages

# How to install
...

# Functionality
...

# Requirements
...

# ETC